function cheakAndFindFatherClass(element,name) {
    while (element.className!== name){
        element=element.parentNode;
        if (element===null){
            return element;
        }
    }
    return element;
}

//打开pdf  pdfjs-canvas
(function() {
        let el = document.getElementById('canvasWrap');
        if (!el) {
            el = document.createElement('div')
            el.id = 'canvasWrap'
            document.body.appendChild(el)
        }
        el.innerHTML = ''
        let winW = document.documentElement.clientWidth
        // 加载 pdf 资源
        let loadingTask = pdfjsLib.getDocument('https://www.lilnong.top/static/pdf/B-4-RxJS%E5%9C%A8React%E4%B8%AD%E7%9A%84%E5%BA%94%E7%94%A8-%E9%BE%99%E9%80%B8%E6%A5%A0_.pdf')
        // PDF 加载完成的回调。
        loadingTask.promise.then(function(pdf) {
            console.log('pdf', pdf)
            // 可以获取到总页数。
            let pageNum = pdf.numPages
            var _pageNum = 1;
            var renderPageToCanvas = function(pageNum, auto=false) {
                // 获取其中的一个页面
                pdf.getPage(pageNum).then(function(page) {
                    // you can now use *page* here
                    _pageNum = pageNum
                    // 获取原始大小的数据
                    var viewport = page.getViewport({
                        scale: 1,
                    });
                    var scale = (500 / viewport.width).toFixed(2)
                    viewport = page.getViewport({
                        scale: scale
                    });
                    var canvas = document.createElement('canvas');
                    el.appendChild(canvas)
                    var context = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    // 创建了一个canvas画板用来存放
                    var renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    page.render(renderContext);
                    if (auto)
                        renderPageToCanvas(pageNum + 1, auto);
                });
            }
            renderPageToCanvas(_pageNum, true);
            canvasPrev.onclick = function() {
                renderPageToCanvas(Math.max(_pageNum - 1, 1));
            }
            canvasNext.onclick = function() {
                renderPageToCanvas(Math.min(_pageNum + 1, pdf.numPages));
            }
        }, function(reason) {
            console.error(reason)
        })

    }
)()

function fetchWithTimeout(fetchPromise, timeout = 10000,controller) {
    // 创建一个 Promise，该 Promise 在指定的超时时间后拒绝
    let state=true;
    let timeoutPromise = new Promise((_, reject) => {
        let id = setTimeout(() => {
            clearTimeout(id);
            if (state){
                outTimeNotic("连接请求超时",2000)
            }

            reject(`Fetch failed: timeout of ${timeout}ms exceeded`);
        }, timeout);
    });

    let fetchthen=fetchPromise.then(response => {
        state=false;
        outTimeNotic("连接成功",1200)
        clearTimeout(id);
        // 如果 fetchPromise 赢了（即请求成功），则返回响应
        return response;
    })
    // 使用 fetch 发起请求
    // 使用 Promise.race 来等待 fetchPromise 或 timeoutPromise 中较快的一个
    return Promise.race([
        fetchthen,
        timeoutPromise
    ]).catch(error => {
        controller.abort()
        // 如果 timeoutPromise 赢了（即超时了），则抛出错误
        throw error;
    });
}
function outTimeNotic(string,time) {
    let create=document.querySelector(".create")
    let ssss=document.createElement("div")
    ssss.setAttribute("class","textbox1");
    ssss.innerText=string
    create.appendChild(ssss);
    window.setTimeout(function () {
        create.removeChild(ssss);
    },time)
}

class CancelToken {
    constructor() {
        this.promise = new Promise((resolve, reject) => {
            this.resolve = resolve;
            this.reject = reject;
        });
    }

    cancel(reason) {
        this.reject(reason);
    }
}

function fetchWithCancelToken(url, cancelToken) {
    return Promise.race([
        fetch(url),
        cancelToken.promise.then(() => Promise.reject(new Error('Fetch cancelled')))
    ]);
}

const controller = new AbortController();
const signal = controller.signal;

// fetch(url, { signal }).then(response => {
//     // 处理响应
// }).catch(e => {
//     if (e.name === 'AbortError') {
//         console.log('Fetch aborted');
//     } else {
//         console.error('Fetch error:', e);
//     }
// });
//
// // 当你需要取消请求时
// controller.abort();
// // 使用示例
// const cancelToken = new CancelToken();
// const fetchPromise = fetchWithCancelToken(url, cancelToken);
//
// // 取消请求
// cancelToken.cancel('Operation cancelled by the user.');

function addgtoch(ele,callback){
    ele.setAttribute('onouchstart',gtouchstart(callback))
    ele.setAttribute('ontouchend',gtouchend())
    ele.setAttribute('ontouchmove',gtouchmove())
    ele.setAttribute('onouchstart',gtouchstart())
}
//开始按
function gtouchstart(callback) {
    timeOutEvent = setTimeout(()=>longPress( callback), 500); //这里设置定时器，定义长按500毫秒触发长按事件，时间可以自己改，个人感觉500毫秒非常合适
    return false;
};

//手释放，如果在500毫秒内就释放，则取消长按事件，此时可以执行onclick应该执行的事件
function gtouchend() {
    clearTimeout(timeOutEvent); //清除定时器
    if (timeOutEvent != 0) {
        //这里写要执行的内容（尤如onclick事件）
        console.log("你这是点击，不是长按");
    }
    return false;
};

//如果手指有移动，则取消所有事件，此时说明用户只是要移动而不是长按
function gtouchmove() {
    clearTimeout(timeOutEvent); //清除定时器
    timeOutEvent = 0;
};

//真正长按后应该执行的内容
function longPress(id) {
    // timeOutEvent = 0;
    // //执行长按要执行的内容，如弹出菜单
    // console.log(id);
    id()
    alert("长按事件触发发");
}
