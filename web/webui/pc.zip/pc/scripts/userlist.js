var item = document.querySelector('.viewArea .item');
var container = document.querySelector('.viewArea').parentNode;

let port = window.location.port
let address = window.location.hostname
console.log(item);
let start = 0; // 开始位置
var pageSize = 20; // 每页展示的数据
var total = 100; //数据总长度

// var itemHeight = 61; // 每个item的高度
var itemStyle = getComputedStyle(item);
var itemHeight = Number(itemStyle.height.split('px')[0]) +
    Number(itemStyle.borderTopWidth.split('px')[0]) +
    Number(itemStyle.borderBottomWidth.split('px')[0]); // 每个item的高度
console.log('itemHeight', itemHeight);


// 设置数据列表的总高度
document.querySelector('#content-l').style.height = itemHeight * total + 'px';
updateDom(start, pageSize, itemHeight, 0);
async function updateDom(start, pageSize, itemHeight, height) {
    document.querySelector('.viewArea').style.transform = 'translateY(' + height + 'px)';
    // document.querySelector('.viewArea').scrollTo(0,height)
    let userlist
    await fetch("http://"+address+":" +port+"/map/Index/Userlist?"+start, {
        method:'get',
        withCredentials: true })
    .then((Response) => Response.json())
    .then((json)=>{userlist=json;})
    reloaditem(userlist,start,pageSize)
}

async function searchupdate( ) {
    let data=document.querySelector('#paraInput')
    let userlist
    await fetch("http://"+address+":" +port+"/map/Index/secrchUserlist?"+data.value, {
        method:'get',
        withCredentials: true })
        .then((Response) => Response.json())
        .then((json)=>{userlist=json;})
    reloaditem(userlist,start,pageSize)
}
function reloaditem(userlist,start, pageSize) {
    let all = document.querySelectorAll(' .viewArea .item');
    let leng = userlist.length;
    // var iterates=Object.entries(userlist)[Symbol.iterator]();
    let su;
    let sn;
    for (var i = start, itemIndex = 0, len = start + pageSize; i < len; i++, itemIndex++) {
        var index = i % pageSize;
        if (leng > i) {
            // st=JSON.stringify(userlist[i])
            st = userlist[i]
            console.log(userlist[i].constructor.name);
            su = st["username"]
            sn = st["nickName"]
            // console.log(s);
            all[itemIndex].innerHTML = '<div class="item0">' + sn + '</div><div class="itemtext">' + su + '</div>'
            all[itemIndex].onclick = function (e) {
                let useName;
                let nickName;
                this.childNodes.forEach((node) => {
                    let docs;
                    if (node.className === 'item0') {
                        nickName = node.innerText;
                    }
                    if (node.className === 'itemtext') {
                        useName = node.innerText;
                        docs = document.querySelectorAll('.Menulist li');
                        let b = true;
                        for (let d in docs) {
                            try {
                                if (docs[d].getAttribute('username') === useName) {
                                    b = false;
                                }
                            } catch (e) {}
                        }
                        if (b) {
                            lodahtml(false)
                            fetch("http://"+address+":" +port+"/map/Index/secrchUserBind?"+useName)
                                .then(Response=>Response.text())
                                .then(text=> {
                                    if (text==="true"){
                                        addLi(useName, nickName, 3)
                                    }})

                        }
                    }
                })
                this.dataset.username=useName;
                if (window.selectUserItem === null || typeof(window.selectUserItem)==="undefined"){
                    window.selectUserItem=this;
                    // this.style.color = '#c9d7e7';
                    this.style.background = 'linear-gradient(rgb(212 235 254), rgb(163 220 255))';
                }else {
                    // window.selectUserItem.style.color = '#7f9ec4'
                    window.selectUserItem.style.background = 'linear-gradient(rgb(220, 232, 246), rgb(181 215 236))';
                    // this.style.color = '#c9d7e7';
                    this.style.background = 'linear-gradient(rgb(212 235 254), rgb(163 220 255))';
                    window.selectUserItem=this;
                }
            }
        } else {
            // all[itemIndex].innerHTML = '<div class="item0">' + sn + '</div><div class="itemtext">' + su + '</div>'
            all[itemIndex].innerHTML = i
        }
        // JSON.stringify(iterates.next());
    }
}

// 滚动处理函数
function handleScroller() {
    var lastStart = 0; // 上次开始的位置
    return () => {
        var currentScrollTop = container.scrollTop;
        var fixedScrollTop = currentScrollTop - currentScrollTop % itemHeight;
        var start = Math.floor(currentScrollTop / itemHeight);
        console.log("handleScroller");
        if (lastStart !== start) {
            lastStart = start;
            updateDom(start, pageSize, itemHeight, fixedScrollTop);
        }
        // else {
        //     updateDom(start, pageSize, itemHeight, fixedScrollTop);
        // }
    }
}
// 防抖和节流
function throttle(fn, delay, atleast) {
    let timer = null;
    let rAFtimer = null;
    let previous = 0;

    return function () {
        let now = Date.now();
        if (now - previous > atleast) {
            console.log('now - previous > atleast');
            fn();
            previous = now;
        } else {
            if (delay > 20) {
                console.log('delay > 20');
                clearTimeout(timer);
                timer = setTimeout(function () {
                    fn();
                    previous = 0;
                }, delay);
            } else {
                console.log('delay < 20');
                cancelAnimationFrame(rAFtimer);
                rAFtimer = requestAnimationFrame(function () {
                    requestIdleCallback(fn);
                });
            }
        }
    }
}
let cont_l=document.querySelector('.viewArea').parentNode;
    cont_l.addEventListener('scroll', throttle(handleScroller(), 16, 500), false);
// document.querySelector('.container').addEventListener('scroll', handleScroller(), false);

window.selectUserItem;
document.querySelector('#bindUser').addEventListener('click',bingUser)
function bingUser() {
    let username=window.selectUserItem.dataset.username;
    let id = setTimeout(() => {
        loadstop()
        outTimeNotic("连接请求超时",2000)
    }, 10000);
    loadstart()
    fetch("http://"+address+":" +port+"/map/Index/linkUser?"+username)
        .then((Response)=> {console.log(Response);return Response.ok})
        .then(ok=>{loadstop();  clearTimeout(id);}).catch(e=>{loadstop();  clearTimeout(id);})
}

document.querySelector('#inbindUser').addEventListener('click',inbingUser)
function inbingUser() {
    let username=window.selectUserItem.dataset.username;
        // .then((Response)=> console.log(Response))
    loadstart()
    fetchWithTimeout(fetch("http://"+address+":" +port+"/map/Index/inlinkUser?"+username))
        .then((Response)=> {console.log(Response);return Response.ok})
        .then(ok=>{loadstop()}).catch(e=>{loadstop()})
}
document.querySelector('#returnbindUser').addEventListener('click',returnbingUser)
function returnbingUser() {
    let username=window.selectUserItem.dataset.username;
    loadstart()
    let con=new AbortController();
    let signal=con.signal;
    let fetchEvent=fetch("http://"+address+":" +port+"/map/Index/reCallLinkUser?"+username,{signal})
    fetchWithTimeout(fetchEvent,con)
        .then((Response)=> {
        console.log(Response);
        return Response.ok})
        .then(ok=>{
            loadstop()})
        .catch(e=>{
            console.log(e)
            loadstop()})
}

document.querySelector('#proxybutton').addEventListener('click',openProxy)
let element_proxy = document.getElementById('proxy_page');
let proxy_load_display_state=true;
function openProxy() {
    if (element_proxy.childElementCount > 0) {
        if (proxy_load_display_state) {
            element_proxy.style.display = 'none'
        } else {
            element_proxy.style.display ='flex'
        }
        proxy_load_display_state=!proxy_load_display_state
    } else {
        $('#proxy_page').load('htmls/proxy.html');
    }
}

let cloudeon=document.getElementById('CloudeOn')
    cloudeon.addEventListener('click',cloudeOn)
let urlCloudOn="http://"+address+":" +port+"/map/ActionCloude/cloudeOn";
let urlCloudOff="http://"+address+":" +port+"/map/ActionCloude/cloudeOff";
let cloudstate=true;

function cloudeOn() {
    let body = document.querySelector(".create")
    let ssss = document.createElement("div");
    ssss.setAttribute("class", "textbox1");
    let url;
    if (cloudstate) {
        url = urlCloudOn
    } else {
        url = urlCloudOff
    }
    fetch(url)
    .then((Response) => {
        if (Response.ok) {
            let text = Response.text()[Symbol.toStringTag].toString()
            if (text !== undefined && text !== null) {
                ssss.innerText = "成功"
                body.appendChild(ssss);
                window.setTimeout(function () {
                    body.removeChild(ssss);
                }, 1500)
                cloudstate = !cloudstate;
                if (cloudstate) {
                    cloudeon.innerText = text
                } else {
                    cloudeon.innerText = text
                }
            }
        } else {
            ssss.innerText = "失败"
            body.appendChild(ssss);
            window.setTimeout(function () {
                body.removeChild(ssss);
            }, 2000)
        }
        console.log(Response)
    })
}



let cloudClear=document.getElementById('CloudClear')
cloudClear.addEventListener('click',cloudeClear)

function cloudeClear() {
    let body = document.querySelector(".create")
    let ssss = document.createElement("div");
    ssss.setAttribute("class", "textbox1");

    fetch("http://" + address + ":" + port + "/map/ActionCloude/cloudeClear")
        .then((Response) => {
            if (Response.ok) {
                if (Response.text()[Symbol.toStringTag] !== "成功")
                    ssss.innerText = Response.text()[Symbol.toStringTag].toString()
                ssss.innerText = "成功"
                body.appendChild(ssss);
                window.setTimeout(function () {
                    body.removeChild(ssss);
                }, 1500)
                cloudstate = true;
                cloudeon.innerText = "cloudeOn"
            } else {
                ssss.innerText = "失败"
                body.appendChild(ssss);
                window.setTimeout(function () {
                    body.removeChild(ssss);
                }, 2000)
            }
            console.log(Response)
        })
}
// document.querySelector('#CloudeOff').addEventListener('click',cloudeOff)
// function cloudeOff() {
//     fetch("http://"+address+":" +port+"/map/ActionCloude/cloudeOff")
//         .then((Response)=> {
//             let body=document.querySelector(".create")
//             let ssss=document.createElement("div")
//             ssss.setAttribute("class","textbox1");
//             ssss.innerText='成功'
//             body.appendChild(ssss);
//             window.setTimeout(function () {
//                 body.removeChild(ssss);
//             },1500)
//             console.log(Response)})
// }


let listhorizontally=document.querySelector(".container .horizontally");
listhorizontally.addEventListener('wheel',wheels)
listhorizontally.addEventListener('scroll',showbinduser);
let showbutton=document.querySelector(".container .vertically .showbtn");
showbutton.addEventListener('click',showbtton);
let showscrollstate=true;
function showbinduser(e) {
    let nod=e.target;
    let nod1=this;
    let len=(nod1.scrollLeft+nod1.clientWidth)-nod1.scrollWidth;
    if (len<=-40){return;}
    let listhorizontally = document.querySelector(".container .vertically .horizontally");
     fetch("http://" + address + ":" + port + "/map/Index/Bindlist" )
        .then((Response) => Response.json())
        .then((json)=>{
            let user;
            listhorizontally.innerHTML='';
            // let cs = window.getComputedStyle(listhorizontally);
            // listhorizontally.childNodes.length;
            let length=Object.keys(json);
            // cs.setProperty('width',length*66+'px');

            // const keys = Object.keys(json);
            // for (let i = keys.length - 1; i >= 0; i--) {
            //     const key = keys[i];
            //     console.log(key, json[key]);
            // }
            for (let i in json){
                user=json[i];
                let  usernode=createnodeclass('binduser',"");

                let nickname=user['nickName'];
                let node
                if (nickname==null||nickname==undefined){
                    node=createnodeclass('txn',"");
                }else {
                    node=createnodeclass('txn',nickname);
                }
                let  username=createnodeclass('tx',user['username']);
                usernode.appendChild(node);
                usernode.appendChild(username);
                getheadpic(usernode,user['username']);
                listhorizontally.appendChild(usernode);
            }
            if (length<5){
                // let hs=' <div class="binduser"><div class="txn"> null</div></div>'
                // listhorizontally.innerHTML=hs+hs+hs+hs+hs+hs;
                for (let i = 0; i <5-length ; i++) {
                    let node =createnodeclass('txn',"");
                    let  usernode=createnodeclass('binduser',"");
                    let  username=createnodeclass('tx',"");
                    usernode.appendChild(node);
                    usernode.appendChild(username);
                    listhorizontally.appendChild(usernode);
                }
            }
            let node =createnodeclass('txn',"");
            let  usernode=createnodeclass('binduser',"");
            let  username=createnodeclass('tx',"到达尽头了");
            usernode.appendChild(node);
            usernode.appendChild(username);
            listhorizontally.appendChild(usernode);
        })
}


function getheadpic(node,u){
    fetch("http://"+address+":" +port+"/map/Index/headPicture?"+u).
    then((Response)=> {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.blob(); // 或者 response.arrayBuffer()
    }).then(imgbuffer=>{
        const objectURL = URL.createObjectURL(imgbuffer);
        const img = document.createElement('img');
        img.src = objectURL;
        node.appendChild(img);
    }) .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
}

function createnodeclass(cls,text) {
    let node=document.createElement('div');
    node.setAttribute('class',cls);
    node.innerText=text;
    return node;
}
function wheels(e){
    //计算鼠标滚轮滚动的距离
    // console.log("scrollLeft", containerWheel.scrollLeft);
    let containerWheel = e.target.parentNode;
    // px = 0.1 * containerWheel.scrollLeft;
    // px2 = e.clientX + px;
    // t0 = e.clientX < leftwidth;

    let v;
    if (e.wheelDelta<0){
        v=true;
    }else {
        v=false
    }
    let i=Math.ceil(Math.abs(e.wheelDelta/(66*2)) );
        // console.log("scrollLeft", containerWheel.scrollLeft);
    if (v){
        // containerWheel.scrollLeft += i*66;
        containerWheel.scrollLeft += i*11;
    }else {
        // containerWheel.scrollLeft += -i*66;
        containerWheel.scrollLeft += -i*11;
    }
    // containerWheel.scrollLeft += -i*66.6;
    //~~containerWheel.style.width.split('px')[0];


}
function showbtton(e) {
    let listvertically=document.querySelector(".container .vertically");
    let contentll=document.querySelector("#content-ll");
    let listcontainer=document.querySelector(".container");
    let i=~~listhorizontally.style.width.split('px')[0];
    if (i<90){
        listvertically.style.width='initial'
        // listvertically.style.width='100vh'
        listhorizontally.style.width='330px';
        listcontainer.style.width='740px';
        contentll.style.display='none';
        // showbutton.style.marginLeft='330px'
    }else {
        listvertically.style.width='72px'
        listhorizontally.style.width='66px';
        listcontainer.style.width='643px';
        contentll.style.display='initial';
        // showbutton.style.marginLeft='60px'
    }
}

let logcatEle=document.querySelector('#logcat')
let logcatEleState=false
logcatEle.addEventListener('mousedown',actviateLogcatEle)
logcatEle.addEventListener('touchstart',actviateLogcatEle)
logcatEle.addEventListener('mouseleave',unActviateLogcatEle)
logcatEle.addEventListener('mouseup',unActviateLogcatEle)
logcatEle.addEventListener('touchend',unActviateLogcatEle)
logcatEle.addEventListener('touchend',unActviateLogcatEle)

function actviateLogcatEle(e) {
    logcatEleState=true
}

function unActviateLogcatEle() {
    logcatEleState=false
}

// setInterval(()=>{
//     if (logcatEleState){
//         return
//     }
//     fetch("http://"+address+":" +port+"/map/Andriod/getLogCat")
//         .then((Response)=> {
//         if (!response.ok) {
//             logcatEle.textContent='Network response was not ok';
//         }
//         return response.text(); // 或者 response.arrayBuffer()
//     }).then(data=>{
//         if (logcatEle.textContent.length<3000){
//             logcatEle.textContent=logcatEle.textContent+'/n'+data
//         }else {
//             logcatEle.textContent=data
//         }
//     })
// },10000)