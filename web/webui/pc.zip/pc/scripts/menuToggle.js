let menuToggle = document.querySelector('.menuToggle')
let sidebar = document.querySelector('.sidebar')
let alogo = document.querySelector('#J_List .logo')
let JList = document.getElementById('J_List')
let showuserlist = document.querySelector("#showuserlist");
let logotext = document.querySelector("#J_List .logo .text");

let J_Listoverflow = true;
alogo.onclick = function () {
    console.log("ttttt")

    if (J_Listoverflow) {
        JList.setAttribute('style', 'overflow-x: auto ');
        J_Listoverflow = false;
        showuserlist.setAttribute('style', ' letter-spacing: 6px; ')
    } else {
        JList.setAttribute('style', 'overflow-x: hidden ');
        J_Listoverflow = true;
        showuserlist.setAttribute('style', ' letter-spacing: 60px; ')
        logotext.setAttribute('style', ' letter-spacing: 60px; ')
    }

    // JList.style.overflow-x =''
    menuToggle.classList.toggle('active')
    sidebar.classList.toggle('active')
    // showuserlist.classList.toggle('active')
}

let Menulist = document.querySelectorAll('.Menulist li')

function activeLink() {
    Menulist.forEach((item) => {
        item.classList.remove('active')
    })
    this.classList.add('active')
}

Menulist.forEach((item) => {
    item.addEventListener('click', activeLink)
})

fetch("http://" + address + ":" + port + "/map/Index/getUser").then(Response => Response.json())
    .then(json => {
        let name = document.querySelector("#showuserlist");
        name.dataset = json
        name.innerText = json['nickName']
        let user = document.querySelector(".logo a");
        user.innerHTML = '<div class="text" style="margin-left: 37px">' + '      ' + json['username'] + '</div>'
        }
    )
// <img alt="" src="https://p1-jj.byteimg.com/tos-cn-i-t2oaga2asx/gold-user-assets/2017/11/27/15ffde661029595b~tplv-t2oaga2asx-jj-mark:3024:0:0:0:q75.png"
// loading="lazy" class="medium-zoom-image">


let userloaddisplaystate = true
let elementuser = document.querySelector('.imgBx');
elementuser.addEventListener('click', loaduser)

// loaduser()
function loaduser() {
    //!element0 && typeof(element0)!="undefined" && element0 !== 0
    console.log("dragloaddisplaystate: " + dragloaddisplaystate)
    if (elementdrag.childElementCount > 0) {

        if (dragloaddisplaystate) {
            dragload();
            elementlist.style.display = 'none'
            elementdrag.style.display = 'flex'
        } else {
            // dragload();
            elementdrag.style.display = 'none'
            elementlist.style.display = 'flex'
        }
        dragloaddisplaystate = !dragloaddisplaystate
    } else {
        $('#drag').load('htmls/cloudeFile.html' + '#' + window.username);
        // $('#table1').load('htmls/table1.html');
        // dragload();
    }

    // element0.innerHTML='<div id="${this.dataset.username}"></div>'

}


let rightCon = document.querySelector('.right-content')
let leftbody = document.querySelector('.leftbody')
let NavConInterface = document.querySelector('#navBarI')
let NavConIfState = false;
let leftbodystate = true;
let menuToggleState = false;
// menuToggle.onclick =
let menuToggleTime;
let menuToggleSetTime;
menuToggle.addEventListener('mousedown', menuToggleDown)
menuToggle.addEventListener('mouseup', menuToggleUp)
menuToggle.addEventListener('mouseout', menuToggleUp)
menuToggle.addEventListener('touchstart', menuToggleDown)
menuToggle.addEventListener('touchmove', menuToggleUp)
menuToggle.addEventListener('touchend', menuToggleUp)

function menuToggleDown(e) {
    if (e.target !== this) {
        return
    }
    // menuToggle.style.transform='scale(1.25)'
    menuToggle.style.borderRadius = '30px'

    menuToggleTime = new Date().getTime()
    menuToggleSetTime = setTimeout(() => {
        console.log("长按事件");
        if (NavConIfState) {
            document.querySelector("#navBG").style.display = 'none'
            document.querySelector("#navCon").style.display = 'none'
            // NavConInterface.style.display='none'
            NavConIfState = false
        } else {
            document.querySelector("#navBG").style.display = 'flex'
            document.querySelector("#navBG").style.zIndex = '7'
            document.querySelector("#navCon").style.display = 'flex'
            // NavConInterface.style.display='flex'
            NavConIfState = true
        }
    }, 800)
    // if (leftbodystate){
    //     leftbody.style.display='none'
    //     // leftbody.style.width='8px'
    //     rightCon.style.marginLeft='2px'
    //     leftbodystate=false;
    // }else {
    //     leftbody.style.display=''
    //     // leftbody.style.width='8px'
    //     rightCon.style.marginLeft='78px'
    //     leftbodystate=true;
    // }
    // // menuToggle.style.display='flex'
    // menuToggle.classList.toggle('active')
    // // sidebar.classList.toggle('active')
}

function menuToggleUp(e) {
    e.stopPropagation()
    e.preventDefault()
    if (e.target !== menuToggle) {
        return
    }

    let menuToggleTime1 = new Date().getTime()
    var t = menuToggleTime1 - menuToggleTime
    console.log('menuToggleUp:  ' + t)
    if (t > 700) {

    } else {
        if (leftbodystate) {
            leftbody.style.display = 'none'
            // leftbody.style.width='8px'
            rightCon.style.marginLeft = '2px'
            leftbodystate = false;
        } else {
            leftbody.style.display = ''
            // leftbody.style.width='8px'
            rightCon.style.marginLeft = '78px'
            leftbodystate = true;
        }
        // menuToggle.style.display='flex'
        menuToggle.classList.toggle('active')

        // sidebar.classList.toggle('active')
    }
    // menuToggle.style.transform='scale(0.8)'
    // menuToggle.style.width='50px';
    // menuToggle.style.height= '50px';
    menuToggle.style.borderRadius = '0px'
    clearTimeout(menuToggleSetTime)
}

// menuToggle.
