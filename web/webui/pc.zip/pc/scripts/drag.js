// let container=document.querySelector('.dragContainer');
// container.ondragstart=e=>{
//     console.log("start",e.log);
// }
let drageableds = document.querySelectorAll(".left div");
let dropeableds = document.querySelectorAll(".right li");
let dropout = document.querySelector("#outdrag");
// let originalPosition = {
//   left: drageableds.offsetLeft,
//   top: drageableds.offsetTop
// };
let leftdiv = {}

function createLeftdiv(target, absolute) {
    let div = document.createElement("div");
    div.innerText = target
    div.dataset.target = target
    div.dataset.absolute = absolute
    leftdiv[absolute + target] = div;
    div.setAttribute('class','dragleft')
    div.setAttribute("draggable", "true");
    div.setAttribute("ondrag", "handleDragStart");
    div.setAttribute("ondragover", "handleDragover");
    div.setAttribute("ondrop", "DropOut");
    return div;
}

function createRightdiv(jsondatas, jsondata) {
    let li = document.createElement("li");
    console.log(jsondatas);
    // li.dataset[jsondata]=jsondatas[JSON.stringify(jsondata)];
    let ss = JSON.stringify(jsondatas);
    li.setAttribute("data", ss);
    li.dataset.locadpath = jsondatas[jsondata]
    let dv = document.createElement("dv");
    dv.innerText = jsondata;
    let a = document.createElement("a");
    a.appendChild(dv);
    li.appendChild(a);
    li.setAttribute("ondragover", "handleDragover");
    li.setAttribute("ondragover", "handleDragleave");
    li.setAttribute("ondrop", "handleDrope");
    li.setAttribute("tdragover", "yes");
    return li;
}

function dragload() {
    drageableds = document.querySelectorAll(".left div");
    dropeableds = document.querySelectorAll(".right li");
    let leftdrag = fetch("http://" + address + ":" + port + "/map/ActionCloude/getCloudePage?" + window.username, {withCredentials: true})
        .then((Response) => Response.json())
        .then((json) => {
            console.log(json);
            return json
        }).then(jsondatas => {
            drageabled = document.querySelector(".left ul");
            drageabled.innerHTML = '';
            leftdiv = {};
            for (var jsondata in jsondatas) {
                var div = createLeftdiv(jsondatas[jsondata]['target'], jsondatas[jsondata]['root']);
                // div.innerText =
                // div.dataset.target = jsondatas[jsondata]['target']
                // div.dataset.absolute =
                // div.setAttribute("draggable", "true");
                // div.setAttribute("ondrag", "handleDragStart");
                // div.setAttribute("ondragover", "handleDragover");
                // div.setAttribute("ondrop", "DropOut");
                drageabled.appendChild(div);
            }
            drageableds = document.querySelectorAll(".left div");

        });

    fetch("http://" + address + ":" + port + "/map/ActionCloude/getCloudeTrigger", {withCredentials: true})
        .then((Response) => Response.json())
        .then((json) => {
            console.log(json);
            return json;
        }).then(jsondatas => {
        dropeabled = document.querySelector(".right ul");
        dropeabled.innerHTML = '';
        for (var jsondata in jsondatas) {
            var li = document.createElement("li");
            console.log(jsondatas);
            // li.dataset[jsondata]=jsondatas[JSON.stringify(jsondata)];
            var ss = JSON.stringify(jsondatas);
            li.setAttribute("data", ss);
            li.dataset.locadpath = jsondatas[jsondata]
            var dv = document.createElement("dv");

            dv.innerText = jsondata;
            a = document.createElement("a");
            a.appendChild(dv);
            li.appendChild(a);
            li.setAttribute("ondragover", "handleDragover");
            li.setAttribute("ondragover", "handleDragleave");
            li.setAttribute("ondrop", "handleDrope");
            addtouchdrog(li)
            dropeabled.appendChild(li);
        }

        fetch("http://" + address + ":" + port + "/map/ActionCloude/getMapTend?" + window.username,
            {withCredentials: true})
            .then((Response) => Response.json())
            .then((json) => {
                console.log(json);
                return json;
            }).then(jsondatas => {
            let nodes = dropeabled.childNodes;
            let div;
            for (let node of nodes) {
                let abp = jsondatas[node.dataset.locadpath]
                if (abp != null && abp !== "[]" && abp !== undefined) {
                    for (let n in abp) {
                        div = leftdiv[abp[n]];
                        if (div != null && div != undefined) {
                            let clonenode = div.cloneNode(true);
                            clonenode.setAttribute("drop", "")
                            clonenode.setAttribute("class", "dropright")
                            clonenode.addEventListener('dragstart', handleDragStart);
                            // element1.removeEventListene('drop', handleDrope)
                            clonenode.addEventListener('drop', function (event) {
                                event.stopPropagation();
                            });
                            addtouchdragRight(clonenode)
                            node.appendChild(clonenode)
                        }
                    }
                }
            }
        })

        dropeableds = document.querySelectorAll(".right li");
        // dropdv = document.querySelectorAll(".right li dv");
        uploadbutton = document.querySelector("#uploadbutton");
        console.log("uploadbutton");
        // uploadbutton.click = uploadTendMap;
        adddrag();
        let showfileelement = document.getElementById('showfile')
        addshowfile(showfileelement);
        var li = document.createElement("li");
        var dv = document.createElement("addBtn");
        dv.setAttribute("class", "addBtn");
        li.appendChild(dv);
        dropeabled.appendChild(li);
        li.addEventListener("click", addfile);
    });
    // uploadbutton = document.querySelector(".uploadbutton");
    // console.log("uploadbutton");
    // uploadbutton.onclick = uploadTendMap;
    // adddrag();
    // let showfileelement = document.getElementById('showfile')
    // adddshowfile(showfileelement);
    // var li = document.createElement("li");
    // var dv = document.createElement("addBtn");
    // dv.setAttribute("class", "addBtn");
    // li.appendChild(dv);
    // dropeabled.appendChild(li);
    // li.addEventListener("click",addfile);
}

dragload();

let dropdv = document.querySelectorAll(".right li dv");
let uploadbutton = document.querySelector("#uploadbutton");
console.log("uploadbutton");

function uploadTendMap() {
    dropeableds = document.querySelectorAll(".right li");
    var listmap = []
    var i1 = 0;
    dropeableds.forEach((dropeabled) => {
        var map = {}
        var list = []
        var i2 = 0;
        var keydata = dropeabled.dataset.locadpath;
        let nodes;
        if (keydata !== null && keydata !== undefined) {
            nodes = dropeabled.childNodes
            nodes.forEach((node) => {
                tn = node.tagName
                if (tn === 'DIV') {
                    // var datacp=div.getData['cloudePage'];
                    var target = node.dataset.target
                    var absolute = node.dataset.absolute
                    list[i2] = absolute + target;
                    i2 = i2 + 1;
                }
            });
            console.log('type of: ' + keydata.constructor.name);
            // map.set(keydata,list)
            map[keydata] = list;
            // listmap.push(map)
            listmap[i1] = map;
            i1 = i1 + 1;
        }
    })
    var jsondatas = JSON.stringify(listmap)
    fetch("http://" + address + ":" + port + "/map/Cloude/TendMap?" + window.username, {
        method: 'post',
        body: jsondatas,
    }).catch(error => {
        console.error(error)})
}


// let showfiles = document.getElementsByClassName(".showfile");
// showfiles.forEach((showfile)=>{
// })

function addshowfile(element) {
    element.addEventListener("dragover", handleDragover);
    // element.addEventListener("dragover", handleDragleave);
    element.addEventListener("drop", getCloudePathList);
}

dataShowFile = {}

function getCloudePathList(e) {
    let ele = e.target
    while (ele.className !== 'showfile') {
        if (ele.parentNode === null) {
            ele = null;
            break;
        }
        ele = ele.parentNode;
    }
    let dragelement = window.drapElement
    let target = dragelement.dataset.target;
    let absolute = dragelement.dataset.absolute;
    let abpath = absolute + target
    if (dataShowFile[abpath] !== null || dataShowFile[abpath] !== undefined) {
        dataShowFile = {}
        let obj = {}
        obj['ab'] = abpath
        obj['name'] = window.username
        // let abs=ab.split('/')
        obj['path'] = target
        let param = JSON.stringify(obj)
        fetch("http://" + address + ":" + port + "/map/show/cPathList1/?" + param)
            .then((Response) => Response.json())
            .then((json) => {
                // let keys = Object.keys(json);
                let divcontains = document.createElement("div");
                divcontains.setAttribute('class', 'filecontain');

                let filelist = document.createElement("div");
                filelist.setAttribute('class', 'filelist');
                let del=document.createElement("div");
                del.setAttribute('class','delfileContarin')
                del.addEventListener('click',delbutton)
                filelist.appendChild(del)
                // let div = document.createElement("div")
                let ss;
                let divn;
                for (let key in json) {
                    divn = document.createElement("div")
                    if (json[key] === 'f') {
                        divn.setAttribute('class', 'file')
                        divn.setAttribute('filename', key)
                        divn.addEventListener('click', openCloudeFile)
                    } else {
                        divn.setAttribute('class', 'path')
                        divn.setAttribute('pathname', key)
                        divn.addEventListener('click', getCloudePathListson)
                    }
                    ss = key.split('/')

                    divn.innerText = ss[ss.length - 1]
                    divn.dataset.abpath = key
                    filelist.appendChild(divn)
                }
                divcontains.dataset.ab = abpath
                divcontains.dataset.name = window.username
                divcontains.appendChild(filelist)
                showfiles = document.getElementsByClassName('showfile');
                showfiles.item(0).appendChild(divcontains)
                filelist.dataset.sn = 0;
                dataShowFile[0] = target;
            })
    }
}

function getCloudePathListson(e) {
    let ele = this.parentNode
    let data = {}
    data['ab'] = ele.parentNode.dataset.ab;
    data['name'] = ele.parentNode.dataset.name;
    let abs = this.dataset.abpath.split('/');
    data['path'] = abs[abs.length - 1];
    let param = JSON.stringify(data);
    loadstart();
    fetch("http://" + address + ":" + port + "/map/show/cPathList", {
        method: 'post',
        body: param
    })
        .then((Response) => Response.json())
        .then((json) => {
            // let keys = Object.keys(json);
            let filelist = document.createElement("div")
            filelist.setAttribute('class', 'filelist')
            // let div = document.createElement("div")
            let ss;
            let divn = document.createElement("div")
            divn.addEventListener("click", removeParentNode)
            divn.setAttribute('class', 'uplay')
            divn.innerText = '...'
            filelist.appendChild(divn)
            // div.appendChild(divn)
            let jsons = JSON.parse(json)
            for (let key in jsons) {
                divn = document.createElement("div")
                if (jsons[key] === 'f') {
                    divn.setAttribute('class', 'file')
                    divn.setAttribute('filename', jsons[key])
                    divn.addEventListener('click', openCloudeFile)
                } else {
                    divn.setAttribute('class', 'path')
                    divn.setAttribute('pathname', jsons[key])
                    divn.addEventListener('click', getCloudePathListson)
                }
                ss = key.split('/')
                divn.addEventListener("mouseover", function () {
                    divn.innerText = key
                })
                divn.addEventListener("mouseout", function () {
                    divn.innerText = ss[ss.length - 1]
                })
                divn.innerText = ss[ss.length - 1]
                divn.dataset.abpath = key
                // div.appendChild(divn)
                filelist.appendChild(divn)
            }
            ele.parentNode.appendChild(filelist)
            let dl = Object.keys(dataShowFile).length
            dl++;
            filelist.dataset.sn = dl;
            loadstart();
            })
        .catch(e=>loadstop())
}

function delElement(e) {
    let ele = e.parentNode
    this.parentNode.removeChild(ele)
}

function openFile(e) {
    let filename = this.getAttribute('filename')
    window.open("http://" + address + ":" + port + "/map/ActionCloude/getFile/?" + filename)
}

function openCloudeFile(e) {
    let filename = this.getAttribute('filename')
    filename=this.dataset.abpath
    let data = {}
    data['name'] = window.username;
    data['file'] = filename
    let d = JSON.stringify(data)
    addDragLoader(this)
    if (filename.includes(".png")|| filename.includes(".jpg")|| filename.includes(".webp")|| filename.includes(".jpeg")){
        loadstart()
        fetch("http://" + address + ":" + port + "/map/ActionCloude/getCloudeFile/?" + d
            // , {
            // method: 'post',
            // body: d,
            // headers: {'Content-Type': 'application/json',},}
        )
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob(); // 获取Blob对象
            })
            .then(blob => {
                // 创建一个对象URL指向Blob对象
                let imageUrl = URL.createObjectURL(blob);
                // 创建一个img元素并设置其src属性为对象URL
                let imgElement = document.createElement('img');
                imgElement.src = imageUrl;
                imgElement.setAttribute('class','picShow');
                let closeElement = document.createElement('div');
                closeElement.setAttribute('class','showPicClose')
                closeElement.addEventListener('click',removeParentNode)
                let imageContainer = document.createElement('div');
                imageContainer.setAttribute('class','showPic')
                let imageContainer0 = document.getElementById('showPicC');
                imageContainer0.appendChild(imageContainer);
                // 将img元素添加到div中
                imageContainer.appendChild(imgElement);
                imageContainer.appendChild(closeElement);
                imageContainer.style.display='flex';
                return imgElement;
            }).then(imageContainer=>{
                // let width=imageContainer.offsetWidth;
                // let height=imageContainer.offsetHeight;
                // let size=width/window.screenTop;
                // imageContainer.style.width=window.screenTop*0.8;
                // imageContainer.style.height=(height/size)*0.8;
            loadstop()
            removeDragLoader(this)
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
                loadstop()
            });
        return;
    }else {

        downloadFile("http://" + address + ":" + port + "/map/ActionCloude/getCloudeFile/?" + d,filename)
    }
    // window.open("http://" + address + ":" + port + "/map/ActionCloude/getCloudeFile/&" + window.username,{
    //     method: 'post',
    //     body: d,
    //     headers: {'Content-Type': 'application/json',},
    // })
}
function downloadFile(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'download';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function removeParentNode(e) {
    e.stopPropagation()
    this.parentNode.parentNode.removeChild(this.parentNode)
}

function getLocalPathList(e) {
    fetch("http://" + address + ":" + port + "/map/ActionCloude/getFile")
}


adddrag();

function adddrag() {
    drageableds.forEach((item) => {
        item.addEventListener('dragstart', handleDragStart)
        // item.addEventListener('touchstart', tochHandleDragStart)
        // item.setAttribute("draggable", "true");
        // item.setAttribute("ondrag", "handleDragStart");
        addtouchdrag(item)
        item.addEventListener("dragover", handleDragover);
        item.addEventListener("drop", DropOut);
    })
    dropeableds.forEach((item) => {
        item.addEventListener("dragover", handleDragover);
        item.addEventListener("dragover", handleDragleave);
        item.addEventListener("drop", handleDrope);
        // addtouchdrog(item)
    })
    dropdv.forEach((item) => {
        item.addEventListener("dragover", handleDragover);
        item.addEventListener("dragover", handleDragleave);
        item.addEventListener("drop", unDrope);
    })
}

// drageableds.addEventListener("dragstart", handleDragStart);
function handleDragStart(e) {
    // console.log(item);
    window.drapElement = e.target;
    e.dataTransfer.effectAllowed = "copy";
    e.dataTransfer.setData("text/plain", e.target.id);
}

function handleDragover(e) {
    e.preventDefault();
    e.target.classList.add("dragover");
    //dropeableds.classList.add("dragover");
}
//dropeableds.addEventListener("dragover", handleDragleave);
function handleDragleave(e) {
    e.preventDefault();
    e.target.classList.remove("dragover");
    //dropeableds.classList.remove("dragover");
}

//dropeableds.addEventListener("drop", handleDrope);
function handleDrope(e) {
    e.stopPropagation();
    // e.preventDefault();
    console.log(item);
    // if (e.target === dropeableds) { // 检查是否在放置区域上放下元素
    //   let dropRect = e.target.getBoundingClientRect(); // 获取放置区域的位置
    //   let newLeft = dropRect.left - originalPosition.left; // 计算新的位置
    //   let newTop = dropRect.top - originalPosition.top; // 计算新的位置
    //   drapElement.style.left = newLeft + "px"; // 设置新位置
    //   drapElement.style.top = newTop + "px"; // 设置新位置
    // }
    e.dataTransfer.effectAllowed = "copy";
    // let draggetId = e.dataTransfer.getData("text/plain");
    let element0 = window.drapElement;

    //element0 = document.getElementById(draggetId);
    let element1 = element0.cloneNode(true);
    // element1.setAttribute("drop", "")
    element1.addEventListener('dragstart', handleDragStart);
    // element1.removeEventListener('drop', handleDrope)
    element1.setAttribute('class','dropright')
    element1.addEventListener('drop', function (event) {
        event.stopPropagation();
    });
    //e.target
    this.appendChild(element1);
    this.classList.add("drop");

    window.drapElement = null;
    uploadTendMap();
}

function unDrope(e) {
    e.stopPropagation();
    e.dataTransfer.effectAllowed = "copy";
    let draggetId = e.dataTransfer.getData("text/plain");
    element0 = drapElement;
    drapElement = null;
    //element0 = document.getElementById(draggetId);
    element1 = element0.cloneNode(true);
    element1.setAttribute("drop", "")
    // element1.setAttribute("class", "dropright")
    element1.addEventListener('dragstart', handleDragStart);
    // element1.removeEventListene('drop', handleDrope)
    element1.addEventListener('drop', function (event) {
        event.stopPropagation();
    });
    e.target.parentNode.appendChild(element1);
    e.target.classList.add("drop");

    uploadTendMap();
}

function DropOut(e) {
    e.preventDefault();
    // e.dataTransfer.effectAllowed = "move";
    ter = e.dataTransfer;
    let draggetId = ter.getData("text/plain");
    var el1 = drapElement;
    if (el1.parentNode.tagName !== 'UL') {
        drapElement = null;
        var el2 = el1.parentNode;
        console.log(el1);
        console.log(el2);
        el2.removeChild(el1);
    }
    // dropeableds.parentNode.removeChild(ell);
    // dropeableds.classList.add("drop");
    uploadTendMap();
}

// listmap.forEach((l1)=>{
//   for (let  entry of l1.entries()) {
//     console.log('' +entry.constructor.name);
//   }
//   l1.forEach((v,k)=>{
//     v.forEach((l2)=>{
//       console.log('k: ',k.constructor.name);
//       console.log('k: ',l2.constructor.name);
//     })
//   })
// })


let opertaAreasid = document.getElementsByClassName("opertaArea")[0]
let showAreasid = document.getElementsByClassName("showfile")[0]
let dragContainer = document.getElementsByClassName("dragContainer")[0]
let opertaContainer = document.getElementsByClassName("cloudeOpertor")[0]



let modeButton = document.querySelector("#modebutton")
modeButton.addEventListener('click', getMode)
function getMode(e) {
    let str = modeButton.textContent
    fetch("http://" + address + ":" + port + "/map/ActionCloude/getCloudeMode?" + str)
        .then((Response) => Response.text())
        .then(text => {
            modeButton.textContent = text;
        })
        .catch(error => console.error(error))
}

document.querySelector('#reqCloude').addEventListener('click',reqCloude)
function reqCloude() {
    loadstart()
    fetch("http://"+address+":" +port+"/map/Cloude/reqCloude?"+window.username)
        .then((Response)=> {Response.text()
        }).then(text=>{
        console.log(Response);
        dragload()
        adddrag();
        loadstop()
        if (cloudstate){
            cloudeOn()
        }
    }).catch(error => loadstop())
}

document.querySelector('#reqCloudeMirror').addEventListener('click',reqCloudeMirror)
function reqCloudeMirror() {
    loadstart()
    fetch("http://"+address+":" +port+"/map/Cloude/reqCloudeMirror?"+window.username)
        .then((Response)=> {console.log(Response);loadstop()})
        .then((Response)=> {Response.text()
        }).then(text=>{
        console.log(Response);
        dragload()
        adddrag();
        loadstop()
    }).catch(error => loadstop())
}

document.querySelector('#immbutton').addEventListener('click',cloudeImmediate)
function cloudeImmediate() {
    fetch("http://"+address+":" +port+"/map/ActionCloude/immediate")
        .then((Response)=> {
            let body=document.querySelector(".create")
            let ssss=document.createElement("div")
            ssss.setAttribute("class","textbox1");
            ssss.innerText=Response.text()[Symbol.toStringTag].toString()
            body.appendChild(ssss);
            window.setTimeout(function () {
                body.removeChild(ssss);
            },1500)
            console.log(Response)})
}
$('#nodebufferTime').load('htmls/t4.html');
let timeFuntion
document.querySelector('#tranTimebutton').addEventListener('click',cloudeTime)
function cloudeTime(e) {
    if (e.target!==this){
        return
    }
    document.querySelector('#nodebufferTime').style.display='initial'
    timeFuntion=timetran
}
function timetran(time) {
    let data={}
    data['user']=window.username
    data['time']=time
    data=JSON.stringify(data)
    fetch("http://"+address+":" +port+"/map/ActionCloude/CloudeTime?"+data)
        .then((Response)=> {
            let body=document.querySelector(".create")
            let ssss=document.createElement("div")
            ssss.setAttribute("class","textbox1");
            ssss.innerText=Response.text()[Symbol.toStringTag].toString()
            body.appendChild(ssss);
            window.setTimeout(function () {
                body.removeChild(ssss);
            },1500)
            console.log(Response)})
}

let chatButton = document.querySelector("#chatbutton")

chatButton.addEventListener('click', getChat)
let chatstate=true
let chatload=true

let counter = 0;
let intervalId;
function getChat() {
    if (chatload){
        $('#chat').load('htmls/chat.html'+ '#' + window.username);
        chatload=false;
        // document.querySelector("#chat").style.display='flex'
    }
    if (chatstate){
        document.querySelector("#chat").style.display='flex'
            intervalId= setInterval(function() {
            console.log(`这个任务已经执行了 ${++counter} 次`);
            reloadchat();
        }, 5000);
        chatstate=false
    }else {
        document.querySelector("#chat").style.display='none'
        clearInterval(intervalId)
        chatstate=true
    }
}



function addtouchdrag(e) {
    e.addEventListener('touchstart', touchstartdrag);
    e.addEventListener('touchmove', touchmovedrag);
    e.addEventListener('touchend', touchenddrag);
}

function addtouchdrog(e) {
    e.addEventListener('touchstart', touchstartdrag);
    e.addEventListener('touchmove', touchmovedrag);
    e.addEventListener('touchend', touchendleft);
}

function addtouchdragRight(e) {
    e.addEventListener('touchstart', touchstartdrag);
    e.addEventListener('touchmove', touchmovedrag);
    e.addEventListener('touchend', touchendRight);
}
let draggableElement;
var isDragging = false;
var startX, startY;
let dragbuffer=document.getElementById('dragbuffer');
let touchX,touchY
var yPosition=0
var xPosition=0
let selectdragElement;
let styleProperties = ['font-size', 'background-color', 'padding', 'border-radius'];
function touchstartdrag(e) {
    // 阻止默认的触摸行为，比如滚动
    e.preventDefault();
    e.stopPropagation()
    console.log("touchstartdrag")
    // 记录开始拖动时的位置
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;

    let element=e.target
    while (element!==this){
        if (element.nodeType === 1){
            element=element.parentNode
        }else {
            return
        }
    }
    draggableElement=element.cloneNode(true)
    selectdragElement=element;
    draggableElement.setAttribute('class','dragleftbuffer')
    let style=window.getComputedStyle(selectdragElement)
    styleProperties.forEach(function(styleName) {
        var styleValue = style.getPropertyValue(styleName);
        if (styleValue) {
            draggableElement.style[styleName] = styleValue;
        }
    });

    var pos = e.target.getBoundingClientRect();
    // draggableElement.style.display='none'
    dragbuffer.innerHTML='';
    dragbuffer.appendChild(draggableElement);
    // yPosition= (e.target.offsetTop - e.target.scrollTop + e.target.clientTop)-40;
    // yPosition= (pos.top)-35;
    yPosition= startY-70;
    // xPosition= (pos.left)-77;
    xPosition=startX+containerWheel.scrollLeft-120
    draggableElement.style.transform = 'translate3d(' + xPosition + 'px, ' + yPosition + 'px, 0)';
    // 标记为正在拖动
    isDragging = true;
    touchX=e.touches[0].clientX
    touchY=e.touches[0].clientY
}

function touchmovedrag(e) {
    // 如果不是拖动状态，则不处理
    if (!isDragging) return;

    // 阻止默认的触摸行为，比如滚动
    e.preventDefault();

    // 计算拖动的距离
    var deltaX = e.touches[0].clientX - startX+xPosition;
    var deltaY = e.touches[0].clientY - startY+yPosition;
    // console.log("deltaX"+deltaX)
    // console.log("deltaY"+deltaY)
    // 在这里处理拖动逻辑，比如更新元素位置
     draggableElement.style.transform = 'translate3d(' + deltaX + 'px, ' + deltaY + 'px, 0)';
    draggableElement.style.display='flex'
    // 更新开始位置，以便计算接下来的移动距离
    touchX=e.touches[0].clientX
    touchY=e.touches[0].clientY
    // startX = e.touches[0].clientX;
    // startY = e.touches[0].clientY;
}

function touchenddrag(e) {
    // 标记为不再拖动
    var touch = e.touches[0]; // 获取第一个触摸点
     console.log("touch"+touch)
    // 获取触摸点在页面上的位置
    var element = document.elementFromPoint(touchX, touchY);
    // let showfileelement = document.getElementById('showfile')
    element=getDragUnder(element,touchX,touchY)
    // element=getUnder(element,touchX,touchY)
    var sct=isElementInsideRightUlLi(element)
    if (sct){
        let buffer=draggableElement.cloneNode(true);
        // let style=window.getComputedStyle(buffer)
        buffer.style = '';
        // styleProperties.forEach(function(styleName) {
        //     buffer.style[styleName] = '';
        //     // style.setProperty(styleName,'initial')
        //
        // });
        // buffer.style.transform = 'translate3d(' + 0 + 'px, ' + 0 + 'px, 0)';
        buffer.setAttribute('class','dropright')
        addtouchdragRight(buffer)
        sct.appendChild(buffer)
    }else {
        element=getUnder(element,touchX,touchX)
        if (element.classList.contains("cloudeOpertor")){
            isShowFile()
        }
        if (element.classList.contains('showfile')){
            isShowFile()
        }

    }
    isDragging = false;
    dragbuffer.removeChild(draggableElement)
    selectdragElement=null;
    adddrag()
    // 在这里处理拖动结束的逻辑，比如动画或位置更新

    uploadTendMap();
}

function touchendleft(e) {


    // 标记为不再拖动
    var touch = e.touches[0]; // 获取第一个触摸点
    console.log("touch"+touch)
    // 获取触摸点在页面上的位置
    var element = document.elementFromPoint(touchX, touchY);
    element=getDragUnder(element,touchX,touchY)
    // while (element !==this ){
    //     if (element.nodeType === 1){
    //         element=element.parentNode
    //     }else {
    //         return
    //     }
    //
    // }

    // let parent = element;
    // var i=0;
    // while (parent && parent.nodeType === 1) { // 确保parent是元素节点
    //     if ( parent.tagName==="LI") {
    //         break
    //     }
    //     i++;
    //     if (i>3){break}
    //     parent = parent.parentNode;
    // }
    // element=getUnder(element,touchX,touchY)
    // var sct=insideTochdragover(element,'tdragover')
    if (element.classList.contains('left')){
        dragbuffer.removeChild(draggableElement)
        selectdragElement.parentNode.removeChild(selectdragElement);
        let path=selectdragElement.dataset.locadpath
        fetch("http://" + address + ":" + port + "/map/ActionCloude/removeCloudeTrigger?" + path)
            .then((Response)=> {
                console.log(Response)})
    }
    selectdragElement=null;
    isDragging = false;
    dragbuffer.removeChild(draggableElement)
    adddrag()
    // 在这里处理拖动结束的逻辑，比如动画或位置更新
    uploadTendMap();
}

function touchendRight(e) {
    // 标记为不再拖动
    var touch = e.touches[0]; // 获取第一个触摸点
    console.log("touch"+touch)
    // 获取触摸点在页面上的位置
    var element = document.elementFromPoint(touchX, touchY);
    element=getDragUnder(element,touchX,touchY)
    // element=getUnder(element,touchX,touchY)
    var sct=element.classList.contains('left')
    if (sct){
        dragbuffer.removeChild(draggableElement)
        selectdragElement.parentNode.removeChild(selectdragElement);
        isDragging = false;
    }
    selectdragElement=null;
    // 在这里处理拖动结束的逻辑，比如动画或位置更新
    uploadTendMap();
}
function getDragUnder(e,x,y) {
        // 临时隐藏顶层元素
        let view=e.style.visibility;
        dragbuffer.style.visibility = 'hidden';
        // 获取隐藏顶层元素后露出的元素
        let belowElement = document.elementFromPoint(x, y);
        // 恢复顶层元素的可见性
        // e.style.visibility = 'visible';
        dragbuffer.style.visibility = view;
        // 返回下层元素
        return belowElement;
}

function isElementInsideRightUlLi(element) {
    // 遍历元素的祖先元素
    var parent = element;
    while (parent && parent.nodeType === 1) { // 确保parent是元素节点
        // 检查父元素是否是ul，并且拥有.right类
        // if (parent.tagName.toLowerCase() === 'ul' && parent.classList.contains('right')) {
        //     // 检查当前元素是否是此ul的直接li子元素
        //     if ( element.tagName.toLowerCase() === 'li') {
        //         return parent;
        //     }
        // }
        if ( parent.tagName.toLowerCase() === 'li') {
            if (parent.classList.contains('right')) {
                return parent;
            }else {
                return false
            }

        }
        // 继续向上查找父元素
        parent = parent.parentNode;
    }
    // 没有找到符合条件的祖先元素
    return false;
}
function insideTochdrag(element, attr="tdrag") {
    // 遍历元素的祖先元素
    let parent = element;
    while (parent && parent.nodeType === 1) { // 确保parent是元素节点
        if ( parent.hasAttribute(attr)) {
            let value = element.getAttribute('even1');
            if (value==="yes"){
                return parent;
            }
        }
        // 继续向上查找父元素
        parent = parent.parentNode;
    }
    // 没有找到符合条件的祖先元素
    return false;
}
function insideTochdragover(element, attribute) {
    // 遍历元素的祖先元素
    let parent = element;
    while (parent && parent.nodeType === 1) { // 确保parent是元素节点
        if ( parent.hasAttribute(attribute)) {
            let value = element.getAttribute(attribute);
            if (value==="yes"){
                return parent;
            }
        }
        // 继续向上查找父元素
        parent = parent.parentNode;
    }
    // 没有找到符合条件的祖先元素
    return false;
}
function getUnder(e,x,y) {
    if (e) {
        // 临时隐藏顶层元素
        let view=e.style.visibility;
        e.style.visibility = 'hidden';
        // 获取隐藏顶层元素后露出的元素
        let belowElement = document.elementFromPoint(x, y);
        // 恢复顶层元素的可见性
        // e.style.visibility = 'visible';
        e.style.visibility = view;
        // 返回下层元素
        return belowElement;
    }
}

function isShowFile(element) {
    // 遍历元素的祖先元素
    let dragelement = draggableElement
    let target = dragelement.dataset.target;
    let absolute = dragelement.dataset.absolute;
    let abpath = absolute + target
    if (dataShowFile[abpath] !== null || dataShowFile[abpath] !== undefined) {
        dataShowFile = {}
        let obj = {}
        obj['ab'] = abpath
        obj['name'] = window.username
        // let abs=ab.split('/')
        obj['path'] = target
        let param = JSON.stringify(obj)
        fetch("http://" + address + ":" + port + "/map/show/cPathList1/?" + param)
            .then((Response) => Response.json())
            .then((json) => {

                // let keys = Object.keys(json);
                let divcontains = document.createElement("div");
                divcontains.setAttribute('class', 'filecontain');

                let filelist = document.createElement("div");
                filelist.setAttribute('class', 'filelist');

                let del=document.createElement("div");
                del.setAttribute('class','delfileContarin')
                del.addEventListener('click',delbutton)
                filelist.appendChild(del)
                // let div = document.createElement("div")
                let ss;
                let divn;
                for (let key in json) {
                    divn = document.createElement("div")
                    if (json[key] === 'f') {
                        divn.setAttribute('class', 'file')
                        divn.setAttribute('filename', key)
                        divn.addEventListener('click', openCloudeFile)
                    } else {
                        divn.setAttribute('class', 'path')
                        divn.setAttribute('pathname', key)
                        divn.addEventListener('click', getCloudePathListson)
                    }
                    ss = key.split('/')

                    divn.innerText = ss[ss.length - 1]
                    divn.dataset.abpath = key
                    filelist.appendChild(divn)
                }
                divcontains.dataset.ab = abpath
                divcontains.dataset.name = window.username


                divcontains.appendChild(filelist)
                showfiles = document.getElementsByClassName('showfile');
                showfiles.item(0).appendChild(divcontains)
                filelist.dataset.sn = 0;
                dataShowFile[0] = target;
            })
    }
    // 没有找到符合条件的祖先元素
    return false;
}

function delbutton(e) {
    this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode)
}
