let myHeading = document.querySelector("h1a1");
myHeading.textContent = "Hello world!";

console.log("main")

let myHead2=document.querySelector("h1");
myHead2.textContent="0"
myHead2.onclick=function(){
    let naa=prompt("w y n");
    alert("hellow"+naa);
};
let st=document.getElementById("show_t");
var str=showTime();
st.textContent=str;

function showTime() {
    var today = new Date;
    var year = today.getFullYear();
    var month = checkNum(today.getMonth() + 1);
    var data = checkNum(today.getDate());
    var hour = today.getHours();
    var minute = checkNum(today.getMinutes());
    var second = checkNum(today.getSeconds());
    var day = today.getDay();
    var a = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    var tip = '上午'
    if (hour > 12) {
        hour -= 12;
        tip = '下午'
    }
    var time = year + '年' + month + '月' + data + '日' + ' ' + tip + ' ' + hour + ':' + minute + ':' +
        second + ' ' + a[day];
    //document.getElementById('time').innerHTML = time;//报错，无法读取内部HTML。
    return time;
}

let dragloaddisplaystate=true
let elementdrag = document.getElementById('drag');
let elementlist = document.getElementById('list');
function lodahtml(state) {
    //!element0 && typeof(element0)!="undefined" && element0 !== 0
    console.log("dragloaddisplaystate: "+dragloaddisplaystate)
    if (state!==null && state!==undefined && typeof(state) ==="boolean"){
        dragloaddisplaystate=state
    }else {
        window.username=this.dataset.username;
    }

    if (elementdrag.childElementCount > 0){
        if (dragloaddisplaystate) {
            dragload();
            elementlist.style.display='none'
            elementdrag.style.display = 'flex'
            dragloaddisplaystate=false
        } else {
            // dragload();
            elementdrag.style.display = 'none'
            elementlist.style.display='flex'
            dragloaddisplaystate=true
        }
        // dragloaddisplaystate = !dragloaddisplaystate
    } else {
        $('#drag').load('htmls/cloudeFile.html' + '#' + window.username);
        if (dragloaddisplaystate) {
            elementlist.style.display='none'
            elementdrag.style.display = 'flex'
            dragloaddisplaystate=false
        } else {
            elementdrag.style.display = 'none'
            elementlist.style.display='flex'
            dragloaddisplaystate=false
        }
        dragloaddisplaystate = !dragloaddisplaystate
        // $('#table1').load('htmls/table1.html');
        // dragload();
    }
    // element0.innerHTML='<div id="${this.dataset.username}"></div>'
  }

function checkNum(num) {
    if (num < 10) {
        return '0' + num;
    }
    return num;
}
// const fetchPromise = fetch(
//     // "https://mdn.github.io/learning-area/javascript/apis/fetching-data/can-store/products.json",
//     // "https://zzz.mihoyo.com/?utm_source=pcad360sem001"
//   );
//   console.log(fetchPromise);console.log("已发送请求……");
//   fetchPromise.then((response) => {
//     console.log(`已收到响应：${response.status}`);
//   });

let loadstate=true
let elementload = document.getElementById('loader');
function loadstart() {
    elementload.style.display='flex'
}
function loadstop() {
    elementload.style.display='none'
}

let elementLogout = document.getElementById('Logout');
elementLogout.addEventListener('click',Logout)
async function Logout() {
    await fetch("http://" + address + ":" + port + "/map/Index/Logout" , {withCredentials: true})
        .then((Response) => Response.json())
        .catch(e=>{
            window.close();
        }).finally(()=>{
            window.close();
        })
}
"http://" + address + ":" + port + "/map/SelfPage/getBackPic"
document.body.style.backgroundImage = "url(http://" + address + ":" + port + "/map/SelfPage/getBackPic)";
// document.body.style.backgroundImage = "url('your-image-url.jpg')";
// 如果需要设置背景不重复，可以添加以下行
document.body.style.backgroundRepeat = "no-repeat";
// 如果需要设置背景尺寸，可以添加以下行
document.body.style.backgroundSize = "cover"; // 或者 "contain", "100% 100%", 等
