console.log("chat11315")
console.log("chat")
let chatpara={}
url=`http://${address}:${port}/map/chat/context?`;
reloadchat();
function reloadchat() {
    fetch(url+window.username,{
        method : 'post',
        body:JSON.stringify(chatpara)}).
    then((Response)=>Response.json()).
    then((json)=>{
        console.log(json);
        return json}).
    then((json)=>{
        var chatContextlist=document.querySelector('.chatcontainer .box');
        let jsons=JSON.parse(json)
        chatContextlist.innerHTML=""
        for(var user of jsons){
            createChatDiv(user,chatContextlist);
        }
    })
}


// window.username='';
function createChatDiv(data,box){
    if (data===undefined||data===null){
        return ;
    }
    var listdiv=document.createElement('div');
    listdiv.setAttribute('class','list');
    var columndiv=document.createElement('div');
    var contextdiv=document.createElement('div');
    var deldiv=document.createElement('div');
    columndiv.setAttribute('class','userColumn');
    columndiv.innerHTML='<img src="'+data['file']+'" alt=""></img>';
    contextdiv.setAttribute('class','content');
    deldiv.setAttribute('class','del');
    deldiv.innerText="x"
    var h1=document.createElement('h1');
    h1.setAttribute('class','sn');
    // var h2=document.createElement('h2');
    var p=document.createElement('p');
    h1.innerHTML='<small>#</small>'+data['date'];
    p.innerText=data['text'];
    if (data['text']===undefined||data['text']===null){
        return ;
    }
    box.appendChild(listdiv);
    listdiv.appendChild(columndiv);
    listdiv.appendChild(contextdiv);

    contextdiv.appendChild(h1)
    // contextdiv.appendChild(h2)
    contextdiv.appendChild(p)
    contextdiv.appendChild(deldiv);
    deldiv.addEventListener('click',delchat);
    contextdiv.dataset.date=data['date'];
    contextdiv.dataset.file=data['file'];
    return listdiv;
}

function chatupdate(e){
    // if (e){
    //     e.stopPropagation()
    // }else {
    //     return;
    // }

    console.log('chatupdate')
    let node=document.querySelector('#chatInput');

    let text=node.value
    if (node.value==="" || node.value===undefined){
        return;
    }
    let rebody={};
    rebody['text']=text

    fetch("http://"+address+":" + port + "/map/chat/postData?"+window.username,{
        method : 'post',
        body:JSON.stringify(rebody)
    }).then((Response)=>Response.text()).
    then(text=>{
        if (text==='""'){
            let body=document.querySelector("BODY")
            let ssss=document.createElement("div")
            ssss.setAttribute("class","textbox");
            ssss.innerText="请求超时"
            body.appendChild(ssss);
            window.setTimeout(function () {
                body.removeChild(ssss);
            },2000)
            return ;
        }
        reloadchat()
        node.value=''
    });
}

let delchatdata=`http://${address}:${port}/map/chat/delData?`;
function delchat(e) {
    let node=e.target.parentNode;
    let chatpara=getElement(e.target)
    fetch(delchatdata+window.username,{
        method : 'post',
        body:JSON.stringify(chatpara)}).
    then((Response)=>Response.json()).
    then((json)=>{
        node.parentNode.parentNode.removeChild(node.parentNode)
        })
}

function getElement(element) {
    // 获取所有的.my-element元素
    let elements = element.parentNode.childNodes;

// 用于存储找到的<a>元素的数组
    let chatpara={}

// 遍历每个.my-element元素
    elements.forEach(child => {
        // 使用querySelectorAll查找该元素下的所有<a>子元素
        // if (child.classList.contains('')){
        //     aChildren = child.querySelectorAll('a');
        // }
        if (child.nodeType === 1 && child.tagName.toLowerCase() === 'p'){
            chatpara['text']=child.textContent
        }
        // 将找到的<a>元素添加到aElements数组中
        // aElements.push(...aChildren);
    });
    chatpara['file']=element.parentNode.dataset.file
    chatpara['date']=element.parentNode.dataset.date
// 现在aElements数组包含了所有的<a>子元素
    return chatpara;
}
